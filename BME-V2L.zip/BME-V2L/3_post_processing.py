import os
import cv2
import numpy as np

data_path = '/root/onethingai-tmp/V2L-Tokenizer/log_eval_inpainting/7B_clip_linear'
data_list = os.listdir(data_path)
end_img = np.zeros((256, 448, 3), dtype=np.uint8)  # 初始化为256x448

# 首先确定每个图像的原始尺寸
original_height, original_width = 128, 128

# 计算中心裁剪后的图像尺寸
crop_height, crop_width = 64, 64
start_height, start_width = (original_height - crop_height) // 2, (original_width - crop_width) // 2

cntx, cnty = 0, 0
valid_extensions = ['.jpg', '.jpeg', '.png', '.bmp']  # 定义有效的图像文件扩展名
for data in data_list:
    # 检查文件扩展名是否有效
    if not any(data.lower().endswith(ext) for ext in valid_extensions):
        print(f"Warning: Skipping non-image file {data}.")
        continue

    img_path = os.path.join(data_path, data)
    img = cv2.imread(img_path)

    # 检查图像是否成功读取
    if img is None:
        print(f"Warning: Unable to load image {img_path}. It will be skipped.")
        continue

    # 进行中心裁剪
    cropped_img = img[start_height:start_height + crop_height, start_width:start_width + crop_width]

    # 将裁剪后的图像放入拼接图像中
    end_img[cnty:cnty + crop_height, cntx:cntx + crop_width] = cropped_img

    # 更新拼接图像的坐标
    cntx += crop_width
    if cntx >= 448:
        cntx = 0
        cnty += crop_height
        if cnty >= 256:
            break  # 如果已经填满一列，则结束循环

# 保存结果图像
cv2.imwrite('fire.png', end_img)