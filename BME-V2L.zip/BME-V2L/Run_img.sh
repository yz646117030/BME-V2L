NO_ALBUMENTATIONS_UPDATE=1
imagenet_path="/root/onethingai-tmp/V2L-Tokenizer/datas"
log_dir="/root/onethingai-tmp/V2L-Tokenizer/output_dir"
#CUDA_VISIBLE_DEVICES=0 torchrun --nproc_per_node 1 --master_port=12593 1_process.py
tasks=( "inpainting" )
for (( k = 0 ; k < ${#tasks[@]} ; k++ ))
do
    task=${tasks[$k]}
    CUDA_VISIBLE_DEVICES=0 torchrun --nproc_per_node 1 --master_port=12593 interpolation.py \
                            --image_size 128 \
                            --n_class 1000 \
                            --max_seq_len 512 \
                            --num_workers 0 \
                            --output_type "next_token_prediction" \
                            --vq_config_path vqgan_configs/v2l.yaml \
                            --output_dir "log_eval_"$task"/7B_clip_linear" \
                            --quantizer_type "org" \
                            --llama_model_path /root/onethingai-tmp/V2L-Tokenizer/data/llama-2-7b \
                            --embed_dim 768 \
                            --n_vision_words 32000 \
                            --local_embedding_path "codebooks/local_codebook_embedding.pth" \
                            --global_embedding_path "codebooks/global_codebook_embedding.pth" \
                            --stage_1_ckpt "checkpoints/v2l-decode.pth" \
                            --batch_size 1 \
                            --global_token_num 21 \
                            --prompt_length 16 \
                            --step 2 \
                            --use_cblinear 1 \
                            --use_crossatt_dec 1 \
                            --task $task
done
CUDA_VISIBLE_DEVICES=0 torchrun --nproc_per_node 1 --master_port=12593 3_post_processing.py
# 设置输出路径和文件名
#output_path="/root/onethingai-tmp/V2L-Tokenizer/log_eval_inpainting/output"
#output_filename="fire.png"
#CUDA_VISIBLE_DEVICES=0 torchrun --nproc_per_node 1 --master_port=12593 4_Gaussian_Filter.py "$output_path" "$output_filename"
# 设置参考图像和预测图像的路径
#image1_path="/root/onethingai-tmp/V2L-Tokenizer/datas/Vimeo90K/car/im2.png" # 参考图像路径
#image2_path="/root/onethingai-tmp/V2L-Tokenizer/datas/output/car.png" # 预测图像路径
# 调用Python脚本并传递图像路径作为参数
#python your_script.py "$image1_path" "$image2_path"