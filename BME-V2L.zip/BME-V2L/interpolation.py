import argparse
import datetime
import json
import os
os.environ['RANK'] = '0'
os.environ['WORLD_SIZE'] = '1'
os.environ['MASTER_ADDR'] = 'localhost'
os.environ['MASTER_PORT'] = '12593'
os.environ['LOCAL_RANK'] = '0'
import sys
import time
from pathlib import Path
import albumentations
import numpy as np
import torch.nn.functional as F
import torch
import torch.backends.cudnn as cudnn
import matplotlib.pyplot as plt
from torch.utils.data import Dataset
from torch.utils.tensorboard import SummaryWriter
from PIL import Image
import yaml
import torch
torch.cuda.set_device(0)
from omegaconf import OmegaConf
import clip
import random

from fairscale.nn.model_parallel.initialize import (
    get_model_parallel_rank,
    initialize_model_parallel,
    model_parallel_is_initialized,
)
import matplotlib
matplotlib.use('agg')
##############
from llama_inference.llama import Tokenizer, ModelArgs
from models.models_v2l import VQModel_LLaMA 
from util.misc import NativeScalerWithGradNormCount as NativeScaler
import util.misc as misc

from sklearn.utils import shuffle


import piq
import pyiqa
from metrics.fid_score.inception import InceptionV3
from scipy import linalg
def calculate_frechet_distance(mu1, sigma1, mu2, sigma2, eps=1e-6):
    """Numpy implementation of the Frechet Distance.
    The Frechet distance between two multivariate Gaussians X_1 ~ N(mu_1, C_1)
    and X_2 ~ N(mu_2, C_2) is
            d^2 = ||mu_1 - mu_2||^2 + Tr(C_1 + C_2 - 2*sqrt(C_1*C_2)).

    Stable version by Dougal J. Sutherland.

    Params:
    -- mu1   : Numpy array containing the activations of a layer of the
               inception net (like returned by the function 'get_predictions')
               for generated samples.
    -- mu2   : The sample mean over activations, precalculated on an
               representative data set.
    -- sigma1: The covariance matrix over activations for generated samples.
    -- sigma2: The covariance matrix over activations, precalculated on an
               representative data set.

    Returns:
    --   : The Frechet Distance.
    """

    mu1 = np.atleast_1d(mu1)
    mu2 = np.atleast_1d(mu2)

    sigma1 = np.atleast_2d(sigma1)
    sigma2 = np.atleast_2d(sigma2)

    assert mu1.shape == mu2.shape, \
        'Training and test mean vectors have different lengths'
    assert sigma1.shape == sigma2.shape, \
        'Training and test covariances have different dimensions'

    diff = mu1 - mu2

    # Product might be almost singular
    covmean, _ = linalg.sqrtm(sigma1.dot(sigma2), disp=False)
    if not np.isfinite(covmean).all():
        msg = ('fid calculation produces singular product; '
               'adding %s to diagonal of cov estimates') % eps
        print(msg)
        offset = np.eye(sigma1.shape[0]) * eps
        covmean = linalg.sqrtm((sigma1 + offset).dot(sigma2 + offset))

    # Numerical error might give slight imaginary component
    if np.iscomplexobj(covmean):
        if not np.allclose(np.diagonal(covmean).imag, 0, atol=1e-3):
            m = np.max(np.abs(covmean.imag))
            raise ValueError('Imaginary component {}'.format(m))
        covmean = covmean.real

    tr_covmean = np.trace(covmean)

    return (diff.dot(diff) + np.trace(sigma1) +
            np.trace(sigma2) - 2 * tr_covmean)




class ImageNetDataset(Dataset):
    def __init__(self, data_root, image_size, model_path, args, max_words=30, n_class=1000, partition="train", device="cpu"):

        self.max_words = max_words
        tokenizer = Tokenizer(model_path=model_path + "/tokenizer.model")
        self.tokenizer1 = tokenizer
        self.device = device
        self.image_size = image_size

        self.data_root = data_root
        
        self.task = args.task


        self.rescaler = albumentations.SmallestMaxSize(max_size=128)
        self.preprocessor = albumentations.Compose([self.rescaler])
        #self.cropper = albumentations.CenterCrop(height=128, width=128)
        #self.preprocessor = albumentations.Compose([self.rescaler, self.cropper])

        self.blur = albumentations.GaussianBlur(blur_limit=(5, 11), p=1)
        self.rotation = albumentations.Rotate(p=1.0)

        _, self.clip_preprocessing = clip.load("ViT-L/14")

        self.image_ids = []
        self.class_labels = []

        liness=os.listdir("datas/test")
        print(liness)
        for lin in liness[1:]:
            self.image_ids.append("test/"+lin)
            self.class_labels.append(int(10))

    def __len__(self):
        return len(self.image_ids)

    def __getitem__(self, index):

        image_ids = self.image_ids[index]
        #image = Image.open(os.path.join(self.data_root, image_ids))
        image = Image.open(os.path.join(self.data_root, image_ids))
        image = image.resize((128,128))
        
        clip_image = self.clip_preprocessing(image)
        if not image.mode == "RGB":
            image = image.convert("RGB")
        image = np.array(image).astype(np.uint8)
        # 检查图像是否已经是 128x128
        #if image.shape[0] == 128 and image.shape[1] == 128:
             # 如果图像已经是 128x128，跳过中心裁剪
              #image = (image / 127.5 - 1.0).astype(np.float32)
        #else:
        image = self.rescaler(image=image)["image"]
        image = self.preprocessor(image=image)["image"]
        image = (image / 127.5 - 1.0).astype(np.float32)
        ##
        if self.task == "deblur":
            image_trans = self.blur(image=image.copy())["image"]
        elif self.task == "rotation":
            image_trans = np.ascontiguousarray(np.rot90(image.copy()))
        elif self.task == "shift":
            image_trans = Image.open(os.path.join(self.data_root, image_ids))
            if not image_trans.mode == "RGB":
                image_trans = image_trans.convert("RGB")
            image_trans = np.array(image_trans).astype(np.uint8)
            image_trans = self.rescaler(image=image_trans)["image"]
            image_trans = image_trans[-128:, -128:, :]
            image_trans = self.cropper(image=image_trans)["image"]
            image_trans = (image_trans / 127.5 - 1.0).astype(np.float32)
        else:
            image_trans = image.copy()

        image_trans = image_trans.transpose(2, 0, 1)
        ##

        image = image.transpose(2, 0, 1)

        #print(image_blur)
        label = self.class_labels[index]

        return [image, image_trans, clip_image, label]


def load_config(config_path, display=False):
  config = OmegaConf.load(config_path)
  if display:
    print(yaml.dump(OmegaConf.to_container(config)))
  return config

def get_args_parser():
    parser = argparse.ArgumentParser("MAE pre-training", add_help=False)
    parser.add_argument(
        "--batch_size",
        default=1,
        type=int,
        help="Batch size per GPU (effective batch size is batch_size * accum_iter * # gpus",
    )
    parser.add_argument("--epochs", default=400, type=int)
    parser.add_argument(
        "--accum_iter",
        default=1,
        type=int,
        help="Accumulate gradient iterations (for increasing the effective batch size under memory constraints)",
    )

    # Model parameters
    parser.add_argument("--llama_model_path", default="/root/onethingai-tmp/V2L-Tokenizer/data/llama-2-7b", type=str, help="path of llama model")
    parser.add_argument("--max_seq_len", type=int, default=512, metavar="LENGTH", help="the maximum sequence length")

    parser.add_argument("--output_dir", default="./output_dir", help="path where to save, empty for no saving")
    parser.add_argument("--device", default="cuda", help="device to use for training / testing")
    parser.add_argument("--seed", default=0, type=int)

    parser.add_argument("--num_workers", default=0, type=int)
    parser.add_argument(
        "--pin_mem",
        action="store_true",
        help="Pin CPU memory in DataLoader for more efficient (sometimes) transfer to GPU.",
    )
    parser.add_argument("--no_pin_mem", action="store_false", dest="pin_mem")
    parser.set_defaults(pin_mem=True)

    # distributed training parameters
    parser.add_argument("--world_size", default=1, type=int, help="number of distributed processes")
    parser.add_argument("--local_rank", default=-1, type=int)
    parser.add_argument("--dist_on_itp", action="store_true")
    parser.add_argument("--dist_url", default="env://", help="url used to set up distributed training")

    parser.add_argument("--imagenet_path", default="/root/onethingai-tmp/V2L-Tokenizer/datas", type=str, help="path of llama model")
    parser.add_argument("--vqgan_path", default="vqgan_weight/vqgan_imagenet_f16_16384", type=str, help="path of llama model")
    
    parser.add_argument("--n_vision_words", default=32000, type=int)
    parser.add_argument("--output_type", default="next_token_prediction", type=str, help="next_token_prediction/classification")
    parser.add_argument("--decode_rate", type=float, default=0, help="Decoding Loss")
    parser.add_argument("--n_class", default=1000, type=int)
    parser.add_argument("--disc_start", default=10000, type=int)
    parser.add_argument("--rate_q", type=float, default=1, help="Decoding Loss")
    parser.add_argument("--rate_p", type=float, default=1, help="VGG Loss")
    parser.add_argument("--rate_llama", type=float, default=0.001, help="Decoding Loss")
    parser.add_argument("--vq_config_path", type=str, default="vqgan_configs/v2l.yaml", help="Decoding Loss")
    parser.add_argument("--llama_start", type=int, default=10000, help="Decoding Loss")
    parser.add_argument("--image_size", type=int, default=128, help="Decoding Loss")
    parser.add_argument("--tuning_codebook", type=int, default=0, help="Decoding Loss")
    parser.add_argument("--stage", type=int, default=2, help="Decoding Loss")
    parser.add_argument("--stage_1_ckpt", type=str, default="checkpoints/v2l-decode.pth", help="Decoding Loss")
    parser.add_argument("--embed_dim", type=int, default=768, help="Decoding Loss")
    parser.add_argument("--quantizer_type", type=str, default="org", help="Decoding Loss")


    parser.add_argument("--way", type=int, default=2, help="Decoding Loss")
    parser.add_argument("--shot", type=int, default=4, help="Decoding Loss")
    parser.add_argument("--times", type=int, default=10000, help="Decoding Loss")
    parser.add_argument("--induction", type=int, default=1, help="Decoding Loss")
    parser.add_argument("--k", type=int, default=1, help="Decoding Loss")

    parser.add_argument("--use_cblinear", type=int, default=1, help="Decoding Loss")
    parser.add_argument("--use_crossatt_enc", type=int, default=0, help="Decoding Loss")
    parser.add_argument("--use_crossatt_dec", type=int, default=1, help="Decoding Loss")
    parser.add_argument("--local_embedding_path", default="codebooks/local_codebook_embedding.pth", type=str, help="path of llama model")
    parser.add_argument("--use_global_branch", type=int, default=0, help="Using Global Branch")
    parser.add_argument("--global_embedding_path", default="codebooks/global_codebook_embedding.pth", type=str, help="path of llama model")

    parser.add_argument("--global_token_num", type=int, default=21, help="Decoding Loss")
    parser.add_argument("--step", type=int, default=2, help="Decoding Loss")
    parser.add_argument("--prompt_length", type=int, default=16, help="Decoding Loss")
    parser.add_argument("--task", default="deblur", type=str, help="path of llama model")
    return parser


def main(args):

    misc.init_distributed_mode(args)

    #torch.multiprocessing.set_start_method('spawn')

    print("job dir: {}".format(os.path.dirname(os.path.realpath(__file__))))
    print("{}".format(args).replace(", ", ",\n"))

    device = torch.device(args.device)
    seed = args.seed + misc.get_rank()
    torch.manual_seed(seed)
    np.random.seed(seed)

    cudnn.benchmark = True
    
    ####
    dataset = ImageNetDataset(
        data_root=args.imagenet_path, image_size=args.image_size, model_path=args.llama_model_path, args=args, max_words=args.max_seq_len, n_class=args.n_class, partition="val", device=device
    )
    block_idx = InceptionV3.BLOCK_INDEX_BY_DIM[2048]
    model_fid = InceptionV3([block_idx]).to(device)
    #pred_arr_source = np.empty((len(dataset.image_ids), 2048))
    #pred_arr_target = np.empty((len(dataset.image_ids), 2048))
    pred_arr_source = np.empty( (5001, 2048) )
    pred_arr_target = np.empty( (5001, 2048) )
    start_idx = 0
    lpips_computer = pyiqa.create_metric('lpips', device=device)
    lpips_total = 0.0

    ####
    psnr_computer = pyiqa.create_metric('psnr', test_y_channel=True, color_space='ycbcr', device=device)
    psnr_total = 0.0
    ssim_total = 0.0
    num_images = 0
    model_fid.eval()
    ###

    ###Load VQ
    config = load_config(args.vq_config_path, display=True)
    vision_tokenizer = VQModel_LLaMA(args=args, **config.model.params)
    vision_tokenizer.to(device)
    if "last" in args.stage_1_ckpt:
        sd = torch.load(os.path.join(args.stage_1_ckpt), map_location="cpu")["model"]
    else:
        sd = torch.load(os.path.join(args.stage_1_ckpt), map_location="cpu")["state_dict"]
    #sd.pop("tok_embeddings.weight")
    missing, unexpected = vision_tokenizer.load_state_dict(sd, strict=False)    
    print(missing)
    vision_tokenizer.eval()
    if args.distributed:
        vision_tokenizer = torch.nn.parallel.DistributedDataParallel(vision_tokenizer, device_ids=[args.gpu])#, find_unused_parameters=True)


    llama_model_path = args.llama_model_path
    from llama_inference.llama import Llama
    generator = Llama.build(
        ckpt_dir=llama_model_path,
        tokenizer_path=llama_model_path + "/tokenizer.model",
        max_seq_len=args.max_seq_len,
        max_batch_size=1,
    )

    num_tasks = misc.get_world_size()
    global_rank = misc.get_rank()


    ##############

    text_tokenizer = Tokenizer(model_path=args.llama_model_path + "/tokenizer.model")
    text_token_embedding = generator.model.tok_embeddings
    clip_texts = np.load("codebooks/global_vocabulary.npy", allow_pickle=True)
    _, clip_preprocess = clip.load("ViT-L/14", device=device)
    rescaler = albumentations.SmallestMaxSize(max_size=128)
    cropper = albumentations.CenterCrop(height=128, width=128)
    preprocess = albumentations.Compose([rescaler, cropper])

    instruction = "Learning a new language and predict the %s tokens following the examples.\n"%(args.step)
        
    #c_tokens = torch.tensor(text_tokenizer.encode("C:<", bos=False, eos=False), dtype=torch.int64).unsqueeze(0).to(args.device)
    in_tokens = torch.tensor(text_tokenizer.encode("###\nInput: < ", bos=False, eos=False), dtype=torch.int64).unsqueeze(0).to(args.device)
    out_tokens = torch.tensor(text_tokenizer.encode(" >\nOutput: ", bos=False, eos=False), dtype=torch.int64).unsqueeze(0).to(args.device)

    in_feature = text_token_embedding(in_tokens)
    out_feature = text_token_embedding(out_tokens)

    q_tokens = torch.tensor(text_tokenizer.encode("\nQ:<", bos=False, eos=False), dtype=torch.int64).unsqueeze(0).to(args.device)
    a_tokens = torch.tensor(text_tokenizer.encode(">\nA:<", bos=False, eos=False), dtype=torch.int64).unsqueeze(0).to(args.device)
    e_tokens = torch.tensor(text_tokenizer.encode(">", bos=False, eos=False), dtype=torch.int64).unsqueeze(0).to(args.device)

    q_feature = text_token_embedding(q_tokens)
    a_feature = text_token_embedding(a_tokens)
    e_feature = text_token_embedding(e_tokens)
    
    if args.use_cblinear == 1:
        vision_tok_embeddings_weight = vision_tokenizer.module.codebook_projection(vision_tokenizer.module.tok_embeddings.weight)
    else:
        vision_tok_embeddings_weight = vision_tokenizer.module.tok_embeddings.weight
    global_tok_embeddings_weight = vision_tokenizer.module.tok_embeddings_global.weight

    data_loader_train = torch.utils.data.DataLoader(
        dataset,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        pin_memory=False,
        drop_last=False,
    )
    disturb_rates = [0.5, 0.47, 0.44, 0.41, 0.38, 0.35, 0.32, 0.29, 0.26, 0.23]
    
    metric_logger = misc.MetricLogger(delimiter="  ")
    header = ""
    print_freq = 10
    os.makedirs(args.output_dir, exist_ok=True)
    for data_iter_step, [images, images_trans, images_clip, class_names] in enumerate(
        metric_logger.log_every(data_loader_train, print_freq, header),start=1
    ):  
        if data_iter_step > 5000:
            break
        images = images.to(args.device)
        images_trans = images_trans.to(args.device)
        images_clip = images_clip.to(args.device)
        '''a = images[1, :, :, :]
        img = a.cpu().numpy()
        img = np.transpose(img, (1, 2, 0))
        img = np.clip(img, 0, 1)
        img = img.astype(np.float32)
        plt.imshow(img)
        save_path = '/root/onethingai-tmp/V2L-Tokenizer/test/images.png'
        plt.savefig(save_path)
        plt.close()
        b = images_trans[1, :, :, :]
        img = b.cpu().numpy()
        img = np.transpose(img, (1, 2, 0))
        img = np.clip(img, 0, 1)
        img = img.astype(np.float32)
        plt.imshow(img)
        save_path = '/root/onethingai-tmp/V2L-Tokenizer/test/images_trans.png'
        plt.savefig(save_path)
        plt.close()
        c = images_clip[1,:,:,:]
        img = c.cpu().numpy()
        img = np.transpose(img, (1, 2, 0))
        img = np.clip(img, 0, 1)
        img = img.astype(np.float32)
        plt.imshow(img)
        save_path = '/root/onethingai-tmp/V2L-Tokenizer/test/images_clip.png'
        plt.savefig(save_path)
        plt.close()'''

        ##Generate Quant
        with torch.no_grad():
            global_feature, d_idx = vision_tokenizer(images, images_clip, 0, step=0, is_val=True, k=args.global_token_num)
            _, d_idx_trans = vision_tokenizer(images_trans, images_clip, 0, step=0, is_val=True, k=args.global_token_num)
        
        d_idx = d_idx.view(images.shape[0], -1)

        target_token = d_idx[-1].clone().unsqueeze(0)

        d_idx_trans = d_idx_trans.view(images.shape[0], -1)
        d_idx_change = d_idx_trans.clone()
        
        ##Disturb Quant
        d_idx_disturb = torch.zeros(len(disturb_rates), d_idx.shape[-1]).long()
        d_idx_disturb_trans = torch.zeros(len(disturb_rates), d_idx.shape[-1]).long()
        select_idx = np.arange(21, d_idx.shape[-1])
        for i, disturb_rate in enumerate(disturb_rates):
            random.shuffle(select_idx)
            disturb_num = np.int64(disturb_rate * d_idx.shape[-1])
            d_idx_disturb[i, :] = d_idx[-1].clone()
            disturb_intance = torch.from_numpy(np.random.randint(32000, size=disturb_num)).to(args.device).long()
            d_idx_disturb[i, select_idx[:disturb_num]] = disturb_intance
            
            d_idx_disturb_trans[i, :] = d_idx_trans[-1].clone()
            d_idx_disturb_trans[i, select_idx[:disturb_num]] = disturb_intance
        
        d_idx_input = d_idx_disturb_trans.clone()
            
        ##Outpainting
        step = args.step
        start = args.global_token_num
        end = 256 + args.global_token_num
        all_pred_tokens = []
        pred_mask = torch.zeros(16, 16)
        if args.task == "inpainting":
            pred_mask[(8-4):(8+4), (8-4):(8+4)] = 1
        elif args.task == "outpainting":
            pred_mask[8:, : ] = 1
        else:
            pred_mask = pred_mask + 1
        pred_mask = pred_mask.view(-1)
        while start < end:
            if pred_mask[start-args.global_token_num] == 0:
                start = start + 1
                continue
            prompt_tokens = torch.tensor(text_tokenizer.encode(instruction, bos=True, eos=False)).unsqueeze(0).to(args.device)
            prompt_features = text_token_embedding(prompt_tokens)
        
            if args.task == "outpainting" or args.task == "inpainting":
                visual_in_tokens = d_idx_disturb[:, (start-args.prompt_length):start]
            else:
                visual_in_tokens = d_idx_disturb_trans[:, start:(start+step)]
            visual_out_tokens = d_idx_disturb[:, start:(start+step)]

            for i in range(0, d_idx_disturb.shape[0]):

                visual_in_token = visual_in_tokens[i].unsqueeze(0)
                visual_in_feature = text_token_embedding(visual_in_token)

                visual_out_token = visual_out_tokens[i].unsqueeze(0)
                visual_out_feature = text_token_embedding(visual_out_token)

                prompt_tokens = torch.cat([prompt_tokens, in_tokens, visual_in_token, out_tokens, visual_out_token], dim=-1)
                prompt_features = torch.cat( [prompt_features, in_feature, visual_in_feature , out_feature, visual_out_feature], dim=1)
        
            if args.task == "outpainting" or args.task == "inpainting":
                visual_in_tokens = d_idx_change[:, (start-args.prompt_length):start]
            else:
                visual_in_tokens = d_idx_change[:, start:(start+step)]
            visual_in_token = visual_in_tokens[-1].unsqueeze(0)
            visual_in_feature = text_token_embedding(visual_in_token)

            visual_out_tokens = d_idx[:, start:(start+step)]
            visual_out_token = visual_out_tokens[-1].unsqueeze(0)
            visual_out_feature = text_token_embedding(visual_out_token)

            prompt_tokens = torch.cat( [prompt_tokens, in_tokens, visual_in_token, out_tokens], dim=-1)
            prompt_features = torch.cat( [prompt_features, in_feature, visual_in_feature, out_feature], dim=1)



            prompt_tokens = prompt_tokens.to(device)
            prompt_features = prompt_features.to(device)
            target_token = target_token.to(device)
            images = images.to(device)

            predictions = generator.generate_fewshot(
                prompt_tokens,
                prompt_features,
                induction=0,
                out_mask = torch.ones(16, 32000).to(args.device),
                max_gen_len=step,
                temperature=0,
                top_p=0.9,
            )

            for prediction in predictions:
                #print(target_text, prediction)
                pred = prediction['tokens']
                pred_text = prediction['generation']
                for token in pred:
                    all_pred_tokens.append(token)
            
            if (start + step) > d_idx_change.shape[1]:
                d_idx_change[-1, start:] = torch.tensor(prediction['tokens'])[:(d_idx_change.shape[1] - start)]
            else:
                d_idx_change[-1, start:(start+step)] = torch.tensor(prediction['tokens'])

            start = start + step

        with torch.no_grad():
            pred_token = torch.tensor(d_idx_change[-1, args.global_token_num:]).unsqueeze(0)#.to(args.device).unsqueeze(0)
            pred_feature = F.embedding(pred_token, vision_tok_embeddings_weight)
            pred_feature = pred_feature.contiguous().permute(0, 2, 1)
            pred_feature = pred_feature.view(pred_feature.shape[0], pred_feature.shape[1], 16, 16)

            gt_token = torch.tensor(target_token[:, args.global_token_num:])
            gt_feature = F.embedding(gt_token, vision_tok_embeddings_weight)
            gt_feature = gt_feature.contiguous().permute(0, 2, 1)
            gt_feature = gt_feature.view(gt_feature.shape[0], gt_feature.shape[1], 16, 16)
            decode_feautres = torch.cat([gt_feature, pred_feature], dim=0)

            if args.use_crossatt_dec != 0:
                pred_global_feature = F.embedding(torch.tensor(d_idx_change[-1, :args.global_token_num]).unsqueeze(0), global_tok_embeddings_weight).contiguous().permute(0, 2, 1).view(pred_feature.shape[0], pred_feature.shape[1], 21)
                gt_global_feature = F.embedding(torch.tensor(target_token[:, :args.global_token_num]), global_tok_embeddings_weight).contiguous().permute(0, 2, 1).view(pred_feature.shape[0], pred_feature.shape[1], 21)
                decode_global_features = torch.cat([gt_global_feature, pred_global_feature], dim=0)
                decode_global_features = decode_global_features.permute(0, 2, 1)
                dec = vision_tokenizer.module.decode(decode_feautres.float(), decode_global_features.float())
            else:
                dec = vision_tokenizer.module.decode(decode_feautres.float())
        

        ###
        lpips_score = lpips_computer(images[-1].unsqueeze(0), dec[-1].unsqueeze(0))
        lpips_total += torch.sum(lpips_score)
        num_images += 1
        metric_logger.update(lpips=lpips_total/num_images)
        ###


        dec = torch.cat([images[-1].unsqueeze(0), images_trans[-1].unsqueeze(0), dec], dim=0)
        dec[dec>1] = 1
        dec[dec<-1] = -1
        dec = (dec + 1) * 127.5
        output = dec[2]
        # 格式化图像序号为三位数
        image_index = "{:03d}".format(data_iter_step)
        plt.imsave(os.path.join(args.output_dir, "{}.jpg".format(image_index)), np.uint8(output.permute(1, 2, 0).cpu().data))

        ###FID
        save_x = dec[0].unsqueeze(0).clone()
        save_xrec = dec[2].unsqueeze(0).clone()
        save_x = save_x / 255.0
        save_xrec = save_xrec / 255.0

        psnr_score = psnr_computer(save_x, save_xrec)
        psnr_total += torch.sum(psnr_score)
        metric_logger.update(psnr=psnr_total/num_images)
        ssim_score = piq.ssim(save_x, save_xrec, data_range=1., reduction='none')
        ssim_total += torch.sum(ssim_score).cpu().data
        metric_logger.update(ssim=ssim_total/num_images)

        with torch.no_grad():
            pred = model_fid(save_x)[0]
            pred_rec = model_fid(save_xrec)[0]

        pred = pred.squeeze(3).squeeze(2).cpu().numpy()
        pred_rec = pred_rec.squeeze(3).squeeze(2).cpu().numpy()

        pred_arr_source[start_idx:start_idx + pred.shape[0]] = pred
        pred_arr_target[start_idx:start_idx + pred_rec.shape[0]] = pred_rec
        start_idx = start_idx + pred.shape[0]

    ##############
    mu1 = np.mean(pred_arr_source, axis=0)
    sigma1 = np.cov(pred_arr_source, rowvar=False)

    mu2 = np.mean(pred_arr_target, axis=0)
    sigma2 = np.cov(pred_arr_target, rowvar=False)

    fid_value = calculate_frechet_distance(mu1, sigma1, mu2, sigma2)
    print(fid_value)
    print("LPIPS:", lpips_total.item()/num_images)
    print("FID:", fid_value)
    print("PSNR:", psnr_total.item()/num_images)
    print("SSIM:", ssim_total.item()/num_images)

    with open(os.path.join(args.output_dir, "recons.csv"), 'a') as f:
        f.write("LPIPS, FID, PSNR, SSIM\n")
        f.write("%.4f, %.4f, %.4f, %.4f\n"%(lpips_total.item()/num_images, fid_value, psnr_total.item()/num_images, ssim_total.item()/num_images))


if __name__ == "__main__":

    args = get_args_parser()
    args = args.parse_args()
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    main(args)
