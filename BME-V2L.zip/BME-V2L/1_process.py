import os
import cv2
import shutil
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm

def find(img, crop_img, x, y, size_dict):
    best_sad = float('inf')
    # 将裁剪的图像转换为YCbCr色彩空间并提取Y通道
    crop_img_ycbcr = cv2.cvtColor(crop_img, cv2.COLOR_BGR2YCrCb)
    gray_crop = crop_img_ycbcr[:, :, 0]  # 提取Y通道

    top, left = size_dict[x][y]
    # 定义一个函数来获取图像块的Y通道并计算SAD
    def get_sad_and_img(img_block):
        gray_img = cv2.cvtColor(img_block, cv2.COLOR_BGR2YCrCb)[:, :, 0]
        sad_value = np.sum(np.abs(gray_crop - gray_img))
        return sad_value, img_block

    # 检查并获取周围的图像块
    sad_values_and_imgs = []
    if top - 2 >= 0:
        sad_value, img_block = get_sad_and_img(img[top-2:top+62, left:left+64, :])
        sad_values_and_imgs.append((sad_value, img_block))
    if top - 1 >= 0:
        sad_value, img_block = get_sad_and_img(img[top-1:top+63, left:left+64, :])
        sad_values_and_imgs.append((sad_value, img_block))
    if top + 66 < img.shape[0]:
        sad_value, img_block = get_sad_and_img(img[top+2:top+66, left:left+64, :])
        sad_values_and_imgs.append((sad_value, img_block))
    if top + 65 < img.shape[0]:
        sad_value, img_block = get_sad_and_img(img[top+1:top+65, left:left+64, :])
        sad_values_and_imgs.append((sad_value, img_block))
    if left - 2 >= 0:
        sad_value, img_block = get_sad_and_img(img[top:top+64, left-2:left+62, :])
        sad_values_and_imgs.append((sad_value, img_block))
    if left - 1 >= 0:
        sad_value, img_block = get_sad_and_img(img[top:top+64, left-1:left+63, :])
        sad_values_and_imgs.append((sad_value, img_block))
    if left + 66 < img.shape[1]:
        sad_value, img_block = get_sad_and_img(img[top:top+64, left+2:left+66, :])
        sad_values_and_imgs.append((sad_value, img_block))
    if left + 65 < img.shape[1]:
        sad_value, img_block = get_sad_and_img(img[top:top+64, left+1:left+65, :])
        sad_values_and_imgs.append((sad_value, img_block))
    sad_value, img_block = get_sad_and_img(img[top:top+64, left:left+64, :])
    sad_values_and_imgs.append((sad_value, img_block))

    # 找到最佳匹配的图像块
    best_sad, result_img = min(sad_values_and_imgs, key=lambda x: x[0])
    return result_img

img_path_1 = '/root/onethingai-tmp/V2L-Tokenizer/datas/preprocessing/img_input/im1.png'
img_path_2 = '/root/onethingai-tmp/V2L-Tokenizer/datas/preprocessing/img_input/im2.png'
img_path_3 = '/root/onethingai-tmp/V2L-Tokenizer/datas/preprocessing/img_input/im3.png'
img_1 = cv2.imread(img_path_1)
img_2 = cv2.imread(img_path_2)
img_3 = cv2.imread(img_path_3)

save_path = '/root/onethingai-tmp/V2L-Tokenizer/datas/test'
if not os.path.exists(save_path):
    os.makedirs(save_path)
else:
    shutil.rmtree(save_path)
    os.makedirs(save_path)

crop_img_1, crop_img_2, crop_img_3 = [], [], []
size_dict = []
for idx in range(4):
    temp_1, temp_2, temp_3 = [], [], []
    temp_size = []
    for idy in range(7):
        # crop_1 = img_1[idx*64:(idx+1)*64, idy*64:(idy+1)*64, :]
        # temp_1.append(crop_1)
        crop_2 = img_2[idx*64:(idx+1)*64, idy*64:(idy+1)*64, :]
        temp_size.append([idx*64, idy*64])
        temp_2.append(crop_2)
        # crop_3 = img_3[idx*64:(idx+1)*64, idy*64:(idy+1)*64, :]
        # temp_3.append(crop_3)
    # crop_img_1.append(temp_1)
    size_dict.append(temp_size)
    crop_img_2.append(temp_2)
    # crop_img_3.append(temp_3)
cnt = 1
for idx in tqdm(range(4)):
    for idy in tqdm(range(7)):
        temp_img_1, temp_img_2, temp_img_3, end_img = np.array([]), np.array([]), np.array([]), np.array([])
        top, bottom, left, right = 0, 0, 0, 0
        center_img = crop_img_2[idx][idy]
        if idx - 1 < 0:
            top = 64
        if idy - 1 < 0:
            left = 64
        if idx + 1 > 3:
            bottom = 64
        if idy + 1 > 6:
            right = 64
        if idx - 1 >= 0 and idy - 1 >= 0:
            temp = find(img_1, crop_img_2[idx-1][idy-1], idx-1, idy-1, size_dict)
            if temp_img_1.size == 0:
                temp_img_1 = temp
            else:
                temp_img_1 = np.concatenate((temp_img_1, temp), axis = 1)
        if idx - 1 >= 0:
            temp = find(img_1, crop_img_2[idx-1][idy], idx-1, idy, size_dict)
            if temp_img_1.size == 0:
                temp_img_1 = temp
            else:
                temp_img_1 = np.concatenate((temp_img_1, temp), axis = 1)
        if idx - 1 >= 0 and idy + 1 <= 6:
            temp = find(img_1, crop_img_2[idx-1][idy+1], idx-1, idy+1, size_dict)
            if temp_img_1.size == 0:
                temp_img_1 = temp
            else:
                temp_img_1 = np.concatenate((temp_img_1, temp), axis = 1)
        if idy - 1 >= 0:
            temp = find(img_1, crop_img_2[idx][idy-1], idx, idy-1, size_dict)
            if temp_img_2.size == 0:
                temp_img_2 = temp
            else:
                temp_img_2 = np.concatenate((temp_img_2, temp), axis = 1)
        if temp_img_2.size == 0:
            temp_img_2 = center_img
        else:
            temp_img_2 = np.concatenate((temp_img_2, center_img), axis = 1)
        if idy + 1 <= 6:
            temp = find(img_3, crop_img_2[idx][idy+1], idx, idy+1, size_dict)
            if temp_img_2.size == 0:
                temp_img_2 = temp
            else:
                temp_img_2 = np.concatenate((temp_img_2, temp), axis = 1)
        if idx + 1 <= 3 and idy - 1 >= 0:
            temp = find(img_3, crop_img_2[idx+1][idy-1], idx+1, idy-1, size_dict)
            if temp_img_3.size == 0:
                temp_img_3 = temp
            else:
                temp_img_3 = np.concatenate((temp_img_3, temp), axis = 1)
        if idx + 1 <= 3:
            temp = find(img_3, crop_img_2[idx+1][idy], idx+1, idy, size_dict)
            if temp_img_3.size == 0:
                temp_img_3 = temp
            else:
                temp_img_3 = np.concatenate((temp_img_3, temp), axis = 1)
        if idx + 1 <= 3 and idy + 1 <= 6:
            temp = find(img_3, crop_img_2[idx+1][idy+1], idx+1, idy+1, size_dict)
            if temp_img_3.size == 0:
                temp_img_3 = temp
            else:
                temp_img_3 = np.concatenate((temp_img_3, temp), axis = 1)
        if temp_img_1.size != 0:
            end_img = temp_img_1
        if end_img.size == 0:
            end_img = temp_img_2
        else:
            end_img = np.concatenate((end_img, temp_img_2), axis = 0)
        if temp_img_3.size != 0:
            end_img = np.concatenate((end_img, temp_img_3), axis = 0)
        end_img = cv2.copyMakeBorder(end_img, top, bottom, left, right, cv2.BORDER_REFLECT)
        end_img = end_img[32:160, 32:160, :]
        cv2.imwrite(os.path.join(save_path, str(cnt).zfill(3) + '.png'), end_img)
        cnt += 1
